package com.slokam.sai;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity

public class course {
	@Id
	@GeneratedValue
	private int id;
	private String cname;
	private String duration;
	
	@ManyToMany
	@JoinTable(name="course_person",
	joinColumns={@JoinColumn(name="cid")},
	inverseJoinColumns={@JoinColumn(name="pid")})
	private List<personpojo> person;
	public List<personpojo> getPerson() {
		return person;
	}
	public void setPerson(List<personpojo> person) {
		this.person = person;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}

	
}
