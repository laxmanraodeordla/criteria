package com.slokam.sai.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.slokam.sai.pojo.product;
import com.slokam.sai.service.Productservice;
@RestController
@RequestMapping("post")
public class Controller {
	@Autowired
private Productservice service;
	@RequestMapping(method= RequestMethod.POST)
public ResponseEntity<String> saveproduct(@RequestBody product product){
		
	service.saveproduct(product);
	ResponseEntity<String> re=new ResponseEntity<String>("welcome 2 my world",HttpStatus.CREATED);
	return re;
}
	@RequestMapping(value="/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteproduct(@PathVariable Integer id){
		service.deleteproduct(id);
		return new ResponseEntity<String>("deleted",HttpStatus.OK);
	}
	
	@RequestMapping(value="/{id}",method=RequestMethod.GET)
	public ResponseEntity<product> getbyproduct(@PathVariable Integer id){
		product pro=service.getbyproduct(id);
		ResponseEntity<product> re=new ResponseEntity<product>(pro,HttpStatus.CREATED);
		return re;
	}
	@RequestMapping( value="/all",method=RequestMethod.GET)
	public ResponseEntity<List<product>> getallproduct(){
		
		List<product> pro=service.getallproduct();
		ResponseEntity<List<product>> re=new ResponseEntity<List<product>>(pro,HttpStatus.CREATED);
		return re;
	}
	
	@RequestMapping(value="/byname/{name}",method=RequestMethod.GET)
	public ResponseEntity<List<product>> selectedproduct(@PathVariable String name){
		List<product> pro=
		service.selecteddata(name+"%");
		ResponseEntity<List<product>> re=new ResponseEntity<List<product>>(pro,HttpStatus.CREATED);
		return re;

	
}
}