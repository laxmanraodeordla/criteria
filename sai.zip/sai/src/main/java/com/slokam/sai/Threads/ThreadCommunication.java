package com.slokam.sai.Threads;

import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.slokam.sai.dao.persondao;
import com.slokam.sai.pojo.personpojo;


public class ThreadCommunication {
	private personpojo pojo = new personpojo();
	private persondao persondao;
	public ThreadCommunication(persondao persondao){
		this.persondao=persondao;
	}
	private boolean isdataavil;
	private boolean notEnd;
	
	synchronized public void saveperson() {
		while (!notEnd) {
		if(!isdataavil){
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
      persondao.save(pojo);
      
	 pojo = new personpojo();
      isdataavil=false;
      notifyAll();
    		  
		
	}
	}
		synchronized public void getperson() throws Exception{
		 FileInputStream fis = new FileInputStream("D:\\New folder (2)\\sai.xlsx");
		 XSSFWorkbook workbook= new XSSFWorkbook(fis);
		XSSFSheet sheet= workbook.getSheet("person");
		Iterator<Row> rowItr = sheet.rowIterator();
		while (rowItr.hasNext()) {
			if (isdataavil) {
				this.wait();
			}

			Row row = rowItr.next();
			Double idDouble = row.getCell(0).getNumericCellValue();

			// int id = idDouble.intValue();
			String name = row.getCell(2).getStringCellValue();
			String qualification = row.getCell(3).getStringCellValue();
			Double ageDouble = row.getCell(1).getNumericCellValue();
			int age = ageDouble.intValue();

			pojo.setAge(age);
			// personpojo.setId(id);
			pojo.setName(name);
			pojo.setQualification(qualification);

			isdataavil = true;
			notifyAll();
		}

		notEnd=true;
	}


		
	}
		
		
	


