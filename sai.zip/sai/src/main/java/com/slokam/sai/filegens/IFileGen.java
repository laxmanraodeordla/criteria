package com.slokam.sai.filegens;

import java.util.List;

import com.slokam.sai.pojo.personpojo;

public interface IFileGen  {

	public void fileGen(List<personpojo> person,String folder);
		
	}


