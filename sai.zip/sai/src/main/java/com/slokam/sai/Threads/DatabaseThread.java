package com.slokam.sai.Threads;

public class DatabaseThread extends Thread {
	private ThreadCommunication communication;
	public DatabaseThread(ThreadCommunication communication){
		this.communication=communication;
	}
    @Override
    public void run() {
    	try {
			communication.getperson();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
	
}
