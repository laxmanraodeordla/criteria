package com.slokam.sai.filegens;

public class FileGenUtility {
	public static IFileGen  genertionObj(String type){
		IFileGen file= null;
		switch(type){
		case"txt":
			file= new TextFile(); 
			break;
		case"excel":
			file= new ExcelSheet(); 
			break;
		case"word":
			file= new WordFile(); 
			break;
		case"pdf":
			file= new Pdf(); 
			break;
		case"xml":
			file= new XmlFile(); 
			break;
			
			
		}
		return file;
	}

}
