package com.slokam.sai.Threads;

import com.slokam.sai.dao.persondao;
import com.slokam.sai.pojo.personpojo;

public class THread2Excel extends Thread {
	private persondao persondao;
	 public THread2Excel(persondao persondao){
		  this.persondao =persondao;
	  }
		 @Override
		public void run() {
			 long starttime=System.currentTimeMillis();
			 int no = ExcelUtil.getNextRecord();
			 while(no >=0){
			   personpojo personPojo = ExcelUtil.getPersonFromExcell(no);	 
			   System.out.println(Thread.currentThread().getName());
			   if(personPojo!=null){ 
				   
				   persondao.save(personPojo);	
				}
			  
			   no = ExcelUtil.getNextRecord(); 
			   
			 }
			 long endtime=System.currentTimeMillis();
			 System.out.println(Thread.currentThread().getName()+"threadtime"+(endtime-starttime));
		 }


}
