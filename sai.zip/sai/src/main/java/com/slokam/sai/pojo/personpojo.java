package com.slokam.sai.pojo;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAnyAttribute;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.sun.xml.internal.txw2.annotation.XmlElement;


@Entity
@Table(name="person")
//@NamedQueries({
//@NamedQuery(name="personquery",query=" select p.id,p.age,pp.ppissuedate, ph.number,c.cname from personpojo p join p.passport pp join p.phone ph join p.courselist c where name=:name" ),
//@NamedQuery(name="passport",query=" select pp.ppissuedate,pp.ppname from personpojo p join p.passport pp where p.name=?")
//})
@XmlRootElement
public class personpojo {
	@Id
	@GeneratedValue
	
	private int id;
	private int age;
	private String name;
	private String qualification;
	
	@ManyToMany
    @JoinTable(
    		name="course_person",
    	    joinColumns={@JoinColumn(name="pid")},
    		inverseJoinColumns={@JoinColumn(name="cid")})
	private List<course> courselist;
	@XmlTransient
	public List<course> getCourselist() {
		return courselist;
	}
	public void setCourselist(List<course> courselist) {
		this.courselist = courselist;
	}
	@OneToMany(mappedBy="person")
private List<phone> phone;
    @XmlTransient
	public List<phone> getPhone() {
		return phone;
	}
	public void setPhone(List<phone> phone) {
		this.phone = phone;
	}
	@OneToOne(mappedBy="person")
	private passportpojo passport;
@XmlTransient
	public passportpojo getPassport() {
		return passport;
	}
	public void setPassport(passportpojo passport) {
		this.passport = passport;
	}
    @XmlAttribute
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@XmlElement
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@XmlElement
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@XmlElement
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	
	
	
	

}
