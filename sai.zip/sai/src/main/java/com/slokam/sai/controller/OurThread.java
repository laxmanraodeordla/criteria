package com.slokam.sai.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import com.slokam.sai.dao.persondao;
import com.slokam.sai.pojo.personpojo;
import com.slokam.sai.service.personservice;


public class OurThread extends Thread {
	@Autowired
	private personservice  service;
	private int startno;
	private int endno;
	private persondao persondao;
	
	public OurThread(int startno,int endno, persondao persondao){
		this.startno=startno;
		this.endno=endno;
		this.persondao=persondao;
		

	}

	public void run() {
		
			FileInputStream fis;
				try {	
			fis = new FileInputStream("D:\\New folder (2)\\sai.xlsx");
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet =workbook.getSheetAt(0);
			List<personpojo> personlist= new ArrayList<personpojo>();
			
			for(int i=startno;i<=endno;i++){
				XSSFRow row= sheet.getRow(i);
				
				
				 double id=row.getCell(0).getNumericCellValue();
				 double age= row.getCell(1).getNumericCellValue();
				 String name=row.getCell(2).getStringCellValue();
				String qualification= row.getCell(3).getStringCellValue();
				Double did=new Double(id);
				Double dage=new Double(age);
				
				personpojo pojo = new personpojo();
				
				pojo.setId(did.intValue());
				pojo.setName(name);
				pojo.setAge(dage.intValue());
				pojo.setQualification(qualification);
				
				personlist.add(pojo);
			}
			persondao.saveAll(personlist);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
			


			}
	}
