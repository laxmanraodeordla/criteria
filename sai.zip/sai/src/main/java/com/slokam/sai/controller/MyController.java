package com.slokam.sai.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.slokam.sai.dao.persondao;
import com.slokam.sai.pojo.personpojo;
import com.slokam.sai.service.personservice;
@RestController
public class MyController {
	@Autowired
	private personservice service;
	
	
	@RequestMapping(value="/personxcel", method= RequestMethod.POST)
	public ResponseEntity<List<personpojo>> savepersonvalues(){
		List<personpojo> personlist = new ArrayList<personpojo>();
		/*try {
			fis = new FileInputStream("D:\\New folder (2)\\sai.xlsx");
		
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet =workbook.getSheetAt(0);
		Iterator<Row> rows=sheet.rowIterator();
		while(rows.hasNext()){
			personpojo pojo = new personpojo();
			Row row=rows.next();
			 double id=row.getCell(0).getNumericCellValue();
			 double age= row.getCell(1).getNumericCellValue();
			 String name=row.getCell(2).getStringCellValue();
			String qualification= row.getCell(3).getStringCellValue();
			Double did=new Double(id);
			Double dage=new Double(age);
			
			
			pojo.setId(did.intValue());
			pojo.setName(name);
			pojo.setAge(dage.intValue());
			pojo.setQualification(qualification);
			personlist.add(pojo);
		}*/
		try {
			service.savepersonvalues(personlist);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		//fis.close();
		/*} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		
				return  new ResponseEntity<List<personpojo>>(HttpStatus.CREATED);
		
		
		
	}

}
