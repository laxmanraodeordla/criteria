package com.slokam.sai.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TreeMap;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.slokam.sai.Threads.DatabaseThread;
import com.slokam.sai.Threads.ExcellThread;
import com.slokam.sai.Threads.THread2Excel;
import com.slokam.sai.Threads.ThreadCommunication;
import com.slokam.sai.controller.OurThread;
import com.slokam.sai.dao.Coursedao;
import com.slokam.sai.dao.Phonedao;
import com.slokam.sai.dao.persondao;
import com.slokam.sai.filegens.CommandExceutor;
import com.slokam.sai.pojo.personpojo;
import com.slokam.sai.resp.Chainclass;
import com.slokam.sai.resp.MessagePersonDataReq;
import com.slokam.sai.resp.MessagePersonDataResp;



@Service
public class personservice {
	@Autowired
	private persondao persondao;
	@Autowired
	private Coursedao course;
	@Autowired
	private Phonedao phone;
	@Autowired
	private JavaMailSender mailsender;
	private boolean workdone;
	
	public List<Object[]> getpersonnamepassportdetailsbyphone(Integer number){
		
		return persondao.getpersonnamepassportdetailsbyphone(number);
		
	}
	public void savepersonvalues(List<personpojo> personlist) throws Exception {
		
	/*	 int startno =0;
	int  endno=9;
		
		 for(int i=1;i<=5;i++){
			 		 OurThread thread= new OurThread(startno, endno, persondao);
			 thread.start();
			 startno=0+10;
			 endno=9+10;
		 }
		 
		 
		
		
		
	*/
		
			/*int lastRow =0;
			try {
				 FileInputStream fis = new FileInputStream("F:\\files\\f20\\person.xlsx");
				 XSSFWorkbook workBook = new XSSFWorkbook(fis);
				 XSSFSheet sheet= workBook.getSheetAt(0);
				 lastRow = sheet.getLastRowNum();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			*/
			/*int statno=0;
			int endno=9;		
			for(int i=1;i<=5;i++){
				ExcellThread t1 = new ExcellThread(statno, endno, personDao);
				t1.start();
				statno = statno+10;
				endno = endno+10;
			}
			
			for(int i=1;i<=5;i++){
			  THread2Excel t1 =  new THread2Excel(persondao);
			  t1.setName("Thread::"+i);
			  t1.start();
			}
			*/
		/*ThreadCommunication communication = new ThreadCommunication(persondao);
		ExcellThread excell = new ExcellThread(communication);
		DatabaseThread db = new DatabaseThread(communication);
		excell.start();
		db.start();
		*/	
		
		
		BlockingQueue<personpojo> queue= new ArrayBlockingQueue<personpojo>(300);
		Runnable excell =()->{
				
				
			
				
		 FileInputStream fis;
			try {
				fis = new FileInputStream("D:\\New folder (2)\\sai.xlsx");
			
		
		 XSSFWorkbook workbook;
		
			workbook = new XSSFWorkbook(fis);
		
		 
		XSSFSheet sheet= workbook.getSheet("person");
		Iterator<Row> rowItr = sheet.rowIterator();
		while (rowItr.hasNext()) {
			Row row = rowItr.next();
			Double idDouble = row.getCell(0).getNumericCellValue();

			// int id = idDouble.intValue();
			String name = row.getCell(2).getStringCellValue();
			String qualification = row.getCell(3).getStringCellValue();
			Double ageDouble = row.getCell(1).getNumericCellValue();
			int age = ageDouble.intValue();
personpojo pojo = new personpojo();
			pojo.setAge(age);
			// personpojo.setId(id);
			pojo.setName(name);
			pojo.setQualification(qualification);
			try {
				queue.put(pojo);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}

		
		
			 catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	};
	Runnable db = ()->{
		for(int i=0;i<=300;i++){
		
			try {
				while(!workdone){
			personpojo pojo=queue.take();
			persondao.save(pojo);}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	};
		new Thread(excell).start();
		new Thread(db).start();
		
	}
	
	public personpojo getbyname(String name){
		personpojo pojo=persondao.getbyname(name);
		
		return pojo;
		
	}
	public List<personpojo>getall(String type,String mail) throws IOException{
		 List<personpojo> personList = persondao.findAll();
			MessagePersonDataResp resp= Chainclass.preperresponse();
			MessagePersonDataReq mpdp = new MessagePersonDataReq();
			mpdp.setFileTypes(type);
			mpdp.setMailsender(mailsender);
			mpdp.setMailid(mail);
			mpdp.setPersonList(personList);
			resp.performRespon(mpdp);
			return personList;
			 
		/*CommandExceutor ce= new CommandExceutor(type);
		List<personpojo> pojo =persondao.findAll();
		ce.excuetecommand(pojo);
		FileOutputStream fos= new FileOutputStream("D:\\New folder (2).zip");
		ZipOutputStream zos= new ZipOutputStream(fos);
		File file = new File("D:\\New folder (2)");
		String[] st=file.list();
		for (String string : st) {
			
			ZipEntry zip = new ZipEntry(string);
			zos.putNextEntry(zip);
			Path path = Paths.get("D:\\New folder (2)\\"+string);
		   byte[] bytes=  Files.readAllBytes(path);
		   zos.write(bytes);
		}
		try {
			MimeMessage mime=mailsender.createMimeMessage();
			
			MimeMessageHelper help = new MimeMessageHelper(mime, true);
			help.addTo(mail);
			help.setFrom("komaravellianusha@gmail.com");
			help.setSubject(" this is  test with attachment");
			help.setText("xml");
			FileSystemResource fsr = new FileSystemResource(
					"D:\\New folder (2)\\prasaddonz.xml");
			help.addAttachment("xml", fsr);
			mailsender.send(mime);
		} catch (MessagingException e) {
			e.printStackTrace();
		}

		zos.close();
		fos.close();
		

		
		 return pojo;
		*/
	}
	
public TreeMap<String, List<String>> getperonsbycourse(){
	List<String> courselist =course.getallcoursenames();
	TreeMap<String, List<String>> map = new TreeMap<String, List<String>>();
	for (String coursenames : courselist) {
		List<String> personlist=persondao.getpersonbycourse(coursenames);
		map.put(coursenames, personlist);
		
	}
	return map;
}



public LinkedHashMap<String,List<String>> getcoursesbyperson(){
	List<String> personlist =persondao.getallpersons();
	LinkedHashMap<String,List<String>> map = new LinkedHashMap<String, List<String>>();
	for (String personnames : personlist) {
		List<String> courselist=course.getcoursesbypersonname(personnames);
		map.put(personnames, courselist);
	}
	
	
	return map;
}




public HashMap<String,List<Integer>> getphonesbyperson(){
	List<String> names=persondao.getallpersons();
	HashMap<String,List<Integer>> map = new HashMap<String, List<Integer>>();
for (String namelist : names) {
	

		List<Integer> numbers=persondao.getallphonesbyperson(namelist);
		map.put(namelist, numbers);
	}
	
	return map;
}


}
