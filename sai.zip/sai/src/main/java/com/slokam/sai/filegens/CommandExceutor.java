package com.slokam.sai.filegens;

import java.util.ArrayList;
import java.util.List;

import com.slokam.sai.pojo.personpojo;

public class CommandExceutor {
	private List<IFileGen> file = new ArrayList<>();
	public CommandExceutor(String type){
		String[]types= type.split(",");
		for (String str : types) {
			IFileGen ifile= FileGenUtility.genertionObj(str);
			file.add(ifile);
			
		}
		
	}
	public void excuetecommand(List<personpojo> personList, String folder){
		for (IFileGen ifile :file ) {
			ifile.fileGen(personList,folder);
			
		}
	}
	

}
