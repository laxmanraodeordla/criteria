package com.slokam.sai.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slokam.sai.pojo.course;
@Repository
public interface Coursedao extends JpaRepository<course, Integer> {
@Query("select c.cname from course c")
public List<String> getallcoursenames();




@Query("select c.cname from personpojo p join p.courselist c where p.name=?1")
public List<String> getcoursesbypersonname(String name);
	
}

