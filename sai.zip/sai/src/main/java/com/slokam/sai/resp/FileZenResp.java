package com.slokam.sai.resp;

import java.io.File;

import com.slokam.sai.filegens.CommandExceutor;

public class FileZenResp extends MessagePersonDataResp{

	
	@Override
	public   void performRespon(MessagePersonDataReq mpdp) {
		 long time = System.currentTimeMillis();
		 String folder = "D:\\New folder (2)"+time;
		 File file = new File(folder);
		 file.mkdir();
		 mpdp.setGenFileFolder(folder);
		 CommandExceutor ce = new CommandExceutor(mpdp.getFileTypes());
		 ce.excuetecommand(mpdp.getPersonList(), folder);
		 
		 nextcall(mpdp);
	}
}
