package com.slokam.sai.filegens;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

import com.slokam.sai.pojo.person;
import com.slokam.sai.pojo.personpojo;

public class XmlFile implements IFileGen {

	@Override
	public void fileGen(List<personpojo> person,String folder) {
		try {
			JAXBContext context = JAXBContext.newInstance(person.class);
			Marshaller marsh = context.createMarshaller();
			marsh.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			person per = new person();
			per.setPersons(person);

			FileOutputStream f = new FileOutputStream(
					folder+"\\prasaddonz.xml");
			marsh.marshal(per, f);
			f.close();
		} catch (PropertyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}
