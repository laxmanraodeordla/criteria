  package com.slokam.sai.resp;

public class Chainclass {
	public static MessagePersonDataResp preperresponse(){
		FileZenResp filezenresp = new FileZenResp();
		ZipFileResp zipres= new ZipFileResp();
		MailZenResp mailres= new MailZenResp();
		
		filezenresp.setNextresp(zipres);
		zipres.setNextresp(mailres);
		return filezenresp;
		
	}

}
