package com.slokam.sai.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class phone {
	@Id
	@GeneratedValue
	private int id;
	private String phonetype;
	private int number;
	@ManyToOne 
	@JoinColumn(name="pid")
	@JsonIgnore
	private personpojo person;
	
	public personpojo getPerson() {
		return person;
	}
	public void setPerson(personpojo person) {
		this.person = person;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPhonetype() {
		return phonetype;
	}
	public void setPhonetype(String phonetype) {
		this.phonetype = phonetype;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
	

}
