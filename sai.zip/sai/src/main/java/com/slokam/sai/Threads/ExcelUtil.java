package com.slokam.sai.Threads;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.slokam.sai.pojo.personpojo;

public class ExcelUtil {

	private static Integer nextRecord = 0;

	public synchronized static Integer getNextRecord() {
		return nextRecord++;
	}

	public static personpojo getPersonFromExcell(int count) {
		personpojo personPojo = null;
		FileInputStream fis;
		try {
			fis = new FileInputStream("D:\\New folder (2)\\sai.xlsx");
			XSSFWorkbook workBook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workBook.getSheetAt(0);
			
			if (count <= sheet.getLastRowNum()) {
				personPojo =new personpojo();
				XSSFRow row = sheet.getRow(count);
				double id = row.getCell(0).getNumericCellValue();
				Double age = row.getCell(1).getNumericCellValue();
				String name = row.getCell(2).getStringCellValue();
				String qualification = row.getCell(3).getStringCellValue();
				personPojo.setAge(age.intValue());
				personPojo.setName(name);
				personPojo.setQualification(qualification);
			}
			
			else
			{
				nextRecord=-5;
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return personPojo;
	}

}



