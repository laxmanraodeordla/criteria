package com.slokam.sai.filegens;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.slokam.sai.pojo.personpojo;

public class TextFile implements IFileGen {

	@Override
	public void fileGen(List<personpojo> person,String folder) {
		try {
			FileWriter fw = new FileWriter(folder+"\\New folder.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			for (personpojo personpojo : person) {
				bw.write(personpojo.getName() + ":" + personpojo.getAge() + ":"
						+ personpojo.getQualification());
				bw.newLine();
			}
			bw.flush();
			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
