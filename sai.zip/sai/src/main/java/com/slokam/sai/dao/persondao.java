  package com.slokam.sai.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slokam.sai.pojo.personpojo;
@Repository
	public interface persondao extends JpaRepository<personpojo,Integer> {
   @Query("select p.name,pt.ppissuedate,ph.phonetype from personpojo p join p.passport pt join p.phone ph where ph.number=?1" )
	public List<Object[]> getpersonnamepassportdetailsbyphone(Integer number);
	
	
	
	@Query("select p.name from personpojo p join p.courselist c where c.cname=?1")	
	public List<String> getpersonbycourse(String course);
	
	@Query("select p.name from personpojo p")
	public List<String> getallpersons();
	
	
	@Query("select ph.number from personpojo p join p.phone ph where p.name=?1")
	public List<Integer> getallphonesbyperson(String name);
	
@Query(" from personpojo p where p.name=?1")	
public personpojo getbyname(String name);




}

