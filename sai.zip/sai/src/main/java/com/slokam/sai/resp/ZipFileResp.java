package com.slokam.sai.resp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipFileResp extends MessagePersonDataResp{
	
	public   void performRespon(MessagePersonDataReq mpdp) {
		 File file = new File(mpdp.getGenFileFolder());
		 String[] files = file.list();
		 String Zipfolderlocation= mpdp.getGenFileFolder()+"\\ourZip.zip";
		 mpdp.setZipFilePath(Zipfolderlocation);
         try(
		 FileOutputStream fos = new FileOutputStream(Zipfolderlocation); 
	     ZipOutputStream zos = new ZipOutputStream(fos);
	){
 		 for(String fileName:files){
 			   ZipEntry entry = new ZipEntry(fileName);
 			   zos.putNextEntry(entry);
 			   Path path = Paths.get(mpdp.getGenFileFolder()+"\\"+fileName);
 			   byte[] bytes = Files.readAllBytes(path);
 			   zos.write(bytes);
 		 }
		 
		 
	}catch(IOException e){
		e.printStackTrace();
	}
         nextcall(mpdp);
}
}