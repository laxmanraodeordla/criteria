package com.slokam.sai.resp;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.MimeMessageHelper;

public class MailZenResp extends MessagePersonDataResp {

	@Override
	public void performRespon(MessagePersonDataReq mpdp) {
MimeMessage message = mpdp.getMailsender().createMimeMessage();
		
		try {
			MimeMessageHelper messageHelper =		
					 new MimeMessageHelper(message,true);
			messageHelper.addTo(mpdp.getMailid());
			messageHelper.setSubject("Test with attachment ");
			messageHelper.setText("This is to test attachment");
			FileSystemResource frs =
					new FileSystemResource(mpdp.getZipFilePath());
			messageHelper.addAttachment("files.zip", frs);
			new Thread(){
				public void run() {
			mpdp.getMailsender().send(message);};}.start();;
			
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		nextcall(mpdp);
		
	}

}
