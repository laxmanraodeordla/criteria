package com.slokam.sai.pojo;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="passport")

public class passportpojo {
	@Id
	@GeneratedValue
	private int ppid;
	private String ppname;
	private String ppissuedate;
	private String ppexpiredate;
	
	
	@OneToOne
	@JoinColumn(name="pid")
	@JsonIgnore
	private personpojo person;
	public int getPpid() {
		return ppid;
	}
	public void setPpid(int ppid) {
		this.ppid = ppid;
	}
	public String getPpname() {
		return ppname;
	}
	public void setPpname(String ppname) {
		this.ppname = ppname;
	}
	public String getPpissuedate() {
		return ppissuedate;
	}
	public void setPpissuedate(String ppissuedate) {
		this.ppissuedate = ppissuedate;
	}
	public String getPpexpiredate() {
		return ppexpiredate;
	}
	public void setPpexpiredate(String ppexpiredate) {
		this.ppexpiredate = ppexpiredate;
	}
	public personpojo getPerson() {
		return person;
	}
	public void setPerson(personpojo person) {
		this.person = person;
	}
	
	

}
