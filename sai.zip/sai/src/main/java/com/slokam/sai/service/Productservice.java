package com.slokam.sai.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




import com.slokam.sai.dao.ProductDao;
import com.slokam.sai.pojo.product;
@Service
public class Productservice {
	
	
	@Autowired
	private ProductDao dao;
	
	public void saveproduct(product product){
    dao.save(product);
	}
	public void deleteproduct(Integer id){
   dao.deleteById(id);
		
		}
	public product getbyproduct(Integer id){
	    Optional<product> optional= dao.findById(id);
	    return optional.get();
		}

	public List<product> getallproduct(){
	    return dao.findAll();
		}
	
	
	
	
	
	public List<product> selecteddata(String name){
	    return dao.seleceddata(name);
	}
	}
