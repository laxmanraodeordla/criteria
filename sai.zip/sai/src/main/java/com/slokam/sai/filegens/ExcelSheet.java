package com.slokam.sai.filegens;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.slokam.sai.pojo.personpojo;

public class ExcelSheet implements IFileGen {

	@Override
	public void fileGen(List<personpojo> person,String folder) {
		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet("person");
			int rowcount = 0;
			for (personpojo personpojo : person) {
				XSSFRow row = sheet.createRow(rowcount);

				row.createCell(0).setCellValue(personpojo.getId());
				row.createCell(1).setCellValue(personpojo.getName());
				row.createCell(2).setCellValue(personpojo.getAge());
				row.createCell(3).setCellValue(personpojo.getQualification());
				rowcount++;
			}
			FileOutputStream fos = new FileOutputStream(
					folder+"\\sai.xlsx");
			workbook.write(fos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}
	

}
