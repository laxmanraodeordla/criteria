package com.slokam.sai.resp;

import java.util.List;

import org.springframework.mail.javamail.JavaMailSender;

import com.slokam.sai.pojo.personpojo;

public class MessagePersonDataReq {

	private List<personpojo> personList;
	private String genFileFolder;
	private String zipFilePath;
    private String fileTypes;
    private JavaMailSender mailsender;
    
    public JavaMailSender getMailsender() {
		return mailsender;
	}

	public void setMailsender(JavaMailSender mailsender) {
		this.mailsender = mailsender;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	private String mailid;
    
	public String getFileTypes() {
		return fileTypes;
	}

	public void setFileTypes(String fileTypes) {
		this.fileTypes = fileTypes;
	}

	public List<personpojo> getPersonList() {
		return personList;
	}

	public void setPersonList(List<personpojo> personList) {
		this.personList = personList;
	}

	public String getGenFileFolder() {
		return genFileFolder;
	}

	public void setGenFileFolder(String genFileFolder) {
		this.genFileFolder = genFileFolder;
	}

	public String getZipFilePath() {
		return zipFilePath;
	}

	public void setZipFilePath(String zipFilePath) {
		this.zipFilePath = zipFilePath;
	}
	

}
