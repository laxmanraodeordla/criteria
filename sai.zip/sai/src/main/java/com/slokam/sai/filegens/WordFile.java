package com.slokam.sai.filegens;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

import com.slokam.sai.pojo.personpojo;

public class WordFile  implements IFileGen{

	@Override
	public void fileGen(List<personpojo> person,String folder) {
		try {
			XWPFDocument document = new XWPFDocument();
			XWPFTable table = document.createTable();
			boolean isfirst = true;
			for (personpojo personpojo : person) {
				XWPFTableRow row = null;
				if (isfirst) {
					row = table.getRow(0);
					row.getCell(0).setText(personpojo.getId() + "");
					row.addNewTableCell().setText(personpojo.getName());
					row.addNewTableCell().setText(personpojo.getAge() + "");
					row.addNewTableCell().setText(personpojo.getQualification());
					isfirst = false;

				} else {
					row = table.createRow();
					row.getCell(0).setText(personpojo.getId() + "");
					row.getCell(1).setText(personpojo.getName());
					row.getCell(2).setText(personpojo.getAge() + "");
					row.getCell(3).setText(personpojo.getQualification());

				}
				FileOutputStream fo = new FileOutputStream(
						folder+"\\saidonk.docx");
				document.write(fo);
				fo.close();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	

}
