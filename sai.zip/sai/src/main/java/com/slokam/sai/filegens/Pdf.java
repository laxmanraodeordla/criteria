package com.slokam.sai.filegens;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.slokam.sai.pojo.personpojo;

public class Pdf implements IFileGen {

	@Override
	public void fileGen(List<personpojo> person,String folder) {
		try {
			Document pdfdocument = new Document();
			FileOutputStream fo = new FileOutputStream(
					folder+"\\prasaddonz.pdf");
			PdfWriter.getInstance(pdfdocument, fo);
			pdfdocument.open();
			PdfPTable pdftable = new PdfPTable(4);
			
			
			
			
			pdftable.addCell("ID");
			pdftable.addCell("NAME");
			pdftable.addCell("AGE");
			pdftable.addCell("QUALIFICATION");

			for (personpojo personpojo : person) {
				pdftable.addCell(personpojo.getId() + "");
				pdftable.addCell(personpojo.getName());
				pdftable.addCell(personpojo.getAge() + "");
				pdftable.addCell(personpojo.getQualification());
			}
			pdfdocument.add(pdftable);
			pdfdocument.close();
			fo.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
