package com.slokam.sai.Threads;

public class ExcellThread extends  Thread {
	private ThreadCommunication communication;
	public ExcellThread(ThreadCommunication communication){
		this.communication=communication;
	}
	@Override
	public void run() {
		try {
			communication.saveperson();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
