package com.slokam.sai.controller;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TreeMap;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Validator;

import org.apache.poi.xslf.usermodel.XSLFSheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.slokam.sai.pojo.person;
import com.slokam.sai.pojo.personpojo;
import com.slokam.sai.service.personservice;

@RestController
@RequestMapping("person")
public class personcontroller {
	@Autowired
	private personservice service;
	@Autowired
	private JavaMailSender mailsender;

	@RequestMapping(value = "/mail/{mail}/{name}", method = RequestMethod.GET)
	public ResponseEntity<String> getmail(@PathVariable String mail,
			@PathVariable String name) {
		personpojo pojo = service.getbyname(name);
		/*SimpleMailMessage messege = new SimpleMailMessage();
		messege.setFrom("anushakomaravelli@gmail.com");
		messege.setTo(mail);
		messege.setSubject("welcome 2 my world");

		messege.setText(pojo.getId() + "" + pojo.getName() + "" + pojo.getAge()
				+ "" + pojo.getQualification());

		mailsender.send(messege);*/

		/*MimeMessage mime = mailsender.createMimeMessage();

		try {
			MimeMessageHelper help = new MimeMessageHelper(mime, true);
			help.addTo(mail);
			help.setFrom("komaravellianusha@gmail.com");
			help.setSubject(" this is  test with attachment");
			help.setText("xml");
			FileSystemResource fsr = new FileSystemResource(
					"D:\\New folder (2)\\prasaddonz.xml");
			help.addAttachment("xml", fsr);
			mailsender.send(mime);
		} catch (MessagingException e) {
			e.printStackTrace();
		}*/

		return new ResponseEntity<String>("success", HttpStatus.CREATED);

	}

	@RequestMapping(value = "/{number}", method = RequestMethod.GET)
	public ResponseEntity<List<Object[]>> getpersonnamepassportdetailsbyphone(
			@PathVariable Integer number) {
		List<Object[]> list = service
				.getpersonnamepassportdetailsbyphone(number);
		ResponseEntity<List<Object[]>> re = new ResponseEntity<List<Object[]>>(
				list, HttpStatus.CREATED);
		return re;

	}

	@RequestMapping(value = "/coursemap", method = RequestMethod.GET)
	public ResponseEntity<TreeMap<String, List<String>>> getperonsbycourse() {
		TreeMap<String, List<String>> map = service.getperonsbycourse();
		ResponseEntity<TreeMap<String, List<String>>> re = new ResponseEntity<TreeMap<String, List<String>>>(
				map, HttpStatus.CREATED);
		return re;

	}

	@RequestMapping(value = "/personmap", method = RequestMethod.GET)
	public ResponseEntity<LinkedHashMap<String, List<String>>> getcoursebypersonname() {
		LinkedHashMap<String, List<String>> map = service.getcoursesbyperson();
		ResponseEntity<LinkedHashMap<String, List<String>>> re = new ResponseEntity<LinkedHashMap<String, List<String>>>(
				map, HttpStatus.CREATED);
		return re;

	}

	@RequestMapping(value = "/personname", method = RequestMethod.GET)
	public ResponseEntity<HashMap<String, List<Integer>>> getphonesbyperson() {
		HashMap<String, List<Integer>> map = service.getphonesbyperson();
		ResponseEntity<HashMap<String, List<Integer>>> re = new ResponseEntity<HashMap<String, List<Integer>>>(
				map, HttpStatus.CREATED);
		return re;

	}

	@RequestMapping(value = "/all/{type}/{mail}", method = RequestMethod.GET)
	public ResponseEntity<List<personpojo>> getall(@PathVariable String type, @PathVariable String mail)
			throws IOException, DocumentException, JAXBException {
		List<personpojo> pojo = service.getall(type,mail);
		ResponseEntity<List<personpojo>> re = new ResponseEntity<List<personpojo>>(
				pojo, HttpStatus.OK);

		/*
		 * // /filetext/////////////
		 * 
		 * FileWriter fw = new FileWriter("D:\\New folder.txt"); BufferedWriter
		 * bw = new BufferedWriter(fw); for (personpojo personpojo : pojo) {
		 * bw.write(personpojo.getName() + ":" + personpojo.getAge() + ":" +
		 * personpojo.getQualification()); bw.newLine(); } bw.flush();
		 * bw.close(); fw.close();
		 * 
		 * // //filetextclose///////////
		 * 
		 * // //////excelsheet////////// XSSFWorkbook workbook = new
		 * XSSFWorkbook(); XSSFSheet sheet = workbook.createSheet("person"); int
		 * rowcount = 0; for (personpojo personpojo : pojo) { XSSFRow row =
		 * sheet.createRow(rowcount);
		 * 
		 * row.createCell(0).setCellValue(personpojo.getId());
		 * row.createCell(1).setCellValue(personpojo.getName());
		 * row.createCell(2).setCellValue(personpojo.getAge());
		 * row.createCell(3).setCellValue(personpojo.getQualification());
		 * rowcount++; } FileOutputStream fos = new FileOutputStream(
		 * "D:\\New folder (2)\\sai.xlsx"); workbook.write(fos);
		 * 
		 * // ///ecxelsheetclose////////////
		 * 
		 * // ///worddocument///////////
		 * 
		 * XWPFDocument document = new XWPFDocument(); XWPFTable table =
		 * document.createTable(); boolean isfirst = true; for (personpojo
		 * personpojo : pojo) { XWPFTableRow row = null; if (isfirst) { row =
		 * table.getRow(0); row.getCell(0).setText(personpojo.getId() + "");
		 * row.addNewTableCell().setText(personpojo.getName());
		 * row.addNewTableCell().setText(personpojo.getAge() + "");
		 * row.addNewTableCell().setText(personpojo.getQualification()); isfirst
		 * = false;
		 * 
		 * } else { row = table.createRow();
		 * row.getCell(0).setText(personpojo.getId() + "");
		 * row.getCell(1).setText(personpojo.getName());
		 * row.getCell(2).setText(personpojo.getAge() + "");
		 * row.getCell(3).setText(personpojo.getQualification());
		 * 
		 * } FileOutputStream fo = new FileOutputStream(
		 * "D:\\New folder (2)\\saidonk.docx"); document.write(fo); fo.close();
		 * } // /////////////worddocument close////////
		 * 
		 * // /////pdffile//////////////
		 * 
		 * Document pdfdocument = new Document(); FileOutputStream fo = new
		 * FileOutputStream( "D:\\New folder (2)\\prasaddonz.pdf");
		 * PdfWriter.getInstance(pdfdocument, fo); pdfdocument.open(); PdfPTable
		 * pdftable = new PdfPTable(4);
		 * 
		 * 
		 * 
		 * 
		 * pdftable.addCell("ID"); pdftable.addCell("NAME");
		 * pdftable.addCell("AGE"); pdftable.addCell("QUALIFICATION");
		 * 
		 * for (personpojo personpojo : pojo) {
		 * pdftable.addCell(personpojo.getId() + "");
		 * pdftable.addCell(personpojo.getName());
		 * pdftable.addCell(personpojo.getAge() + "");
		 * pdftable.addCell(personpojo.getQualification()); }
		 * pdfdocument.add(pdftable); pdfdocument.close(); fo.close(); //
		 * ////pdfclose/////////
		 * 
		 * // ////xmlopen////////
		 * 
		 * JAXBContext context = JAXBContext.newInstance(person.class);
		 * Marshaller marsh = context.createMarshaller();
		 * marsh.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true); person per
		 * = new person(); per.setPersons(pojo);
		 * 
		 * FileOutputStream f = new FileOutputStream(
		 * "D:\\New folder (2)\\prasaddonz.xml"); marsh.marshal(per, f);
		 * f.close();
		 */return re;
	}

}