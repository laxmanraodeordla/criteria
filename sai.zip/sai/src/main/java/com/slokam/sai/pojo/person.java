package com.slokam.sai.pojo;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class person {
	private List<personpojo> persons;
@XmlElement
	public List<personpojo> getPersons() {
		return persons;
	}

	public void setPersons(List<personpojo> persons) {
		this.persons = persons;
	}

	public void setId(Integer id) {
		// TODO Auto-generated method stub
		
	}

}
