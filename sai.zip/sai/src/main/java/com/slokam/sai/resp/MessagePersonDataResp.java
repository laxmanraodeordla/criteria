package com.slokam.sai.resp;

public abstract class MessagePersonDataResp {
	private  MessagePersonDataResp nextresp;
	
	public void setNextresp(MessagePersonDataResp nextresp) {
		this.nextresp = nextresp;
	}
	public void nextcall(MessagePersonDataReq mpdp){
		if(nextresp!=null){
		nextresp.performRespon(mpdp);
		}
	}


	public abstract  void performRespon(MessagePersonDataReq mpdp);
	
}
