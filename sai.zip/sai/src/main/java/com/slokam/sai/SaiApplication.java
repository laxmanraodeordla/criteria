package com.slokam.sai;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.slokam.sai.controller.personcontroller;
//@EntityScan("com.slokam.sai.pojo")
//@ComponentScan({"com.slokam.sai.controller","com.slokam.sai.service"})
//@EnableJpaRepositories(" com.slokam.sai.dao")
@SpringBootApplication
public class SaiApplication {

	public static void main(String[] args) {
				SpringApplication.run(SaiApplication.class, args);
	}
}
 